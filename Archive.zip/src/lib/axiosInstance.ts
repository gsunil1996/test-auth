import axios, { AxiosRequestConfig, AxiosResponse, AxiosError, InternalAxiosRequestConfig } from 'axios';

// Create an Axios instance
const axiosInstance = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_BASE_URL, // Use environment variables for base URL
  timeout: 10000, // Set a timeout if needed
});

// Request interceptor
axiosInstance.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    // Add multiple headers if necessary
    if (typeof window !== 'undefined') {
      const token = localStorage.getItem('token');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      // Add other custom headers
      config.headers['X-Custom-Header'] = 'CustomHeaderValue';
      config.headers['Another-Header'] = 'AnotherHeaderValue';
    }
    return config;
  },
  (error: AxiosError) => {
    // Handle request errors here
    return Promise.reject(error);
  }
);

// Response interceptor
axiosInstance.interceptors.response.use(
  (response: AxiosResponse) => {
    // Any status code within the range of 200 will trigger this function
    return response;
  },
  (error: AxiosError) => {
    // // Any status code outside the range of 200 will trigger this function
    // if (error.response && error.response.status === 401) {
    //   if (typeof window !== 'undefined') {
    //     window.location.href = '/login'; // Adjust as needed
    //   }
    // }
    return Promise.reject(error);
  }
);

export default axiosInstance;
