export type CounterState = {
  value: number;
};
