import { createAsyncThunk } from "@reduxjs/toolkit";
import axios, { AxiosError, AxiosResponse } from "axios";
import { baseUrl } from "./baseUrl";
import { ErrorResponseType } from "@/types/crud.types";
import { payloadTypes } from "@/types/common.types";
import handleError from "./errorHandler";
import { toast } from "react-toastify";

// Function to refresh the access token
export const refreshAccessToken = async () => {
  const refresh_token = localStorage.getItem("refresh_token");

  try {
    const response = await axios.get(`${baseUrl}/refresh`, {
      headers: {
        Authorization: `Bearer ${refresh_token}`,
      },
    });

    localStorage.setItem("token", response.data.token);

    return response.data;
  } catch (error) {
    return error;
  }
};

// Function to create an async thunk with token refresh functionality
export const createAsyncThunkWithTokenRefresh = <
  PayloadType extends payloadTypes,
  ReturnType
>(
  type: string,
  requestFunction: (payload: PayloadType) => Promise<AxiosResponse<ReturnType>>
) =>
  createAsyncThunk(`${type}`, async (payload: PayloadType, thunkAPI) => {
    try {
      // Make the initial request using the provided function and token
      const response = await requestFunction(payload);

      return response.data;
    } catch (error) {
      const axiosError = error as AxiosError<ErrorResponseType>;

      if (axiosError.response?.status === 401) {
        try {
          // call for refresh token
          await refreshAccessToken();

          try {
            // Retry the original request with the new access token
            const retryResponse = await requestFunction(payload);

            return retryResponse.data;
          } catch (retryError) {
            const axiosRetryError = retryError as AxiosError<ErrorResponseType>;
            console.log("axiosRetryError", axiosRetryError)
            if (axiosRetryError?.response?.data?.error === "Invalid Token" || axiosRetryError?.response?.data?.error === "There is no token") {
              toast("Your Session is expired, Please Login", {
                autoClose: 2000,
                type: "error",
              });
              setTimeout(() => {
                window.location.href = "/login";
              }, 1000);
            } else {
              return thunkAPI.rejectWithValue(handleError(retryError));
            }
          }
        } catch (refreshError) {
          console.log("refreshError", refreshError);
          return thunkAPI.rejectWithValue(handleError(refreshError));
        }
      } else {
        return thunkAPI.rejectWithValue(handleError(error));
      }
    }
  });
