import { createSlice } from "@reduxjs/toolkit";
import {
  AddSuccessApiResponse,
  CrudInitialState,
  DeleteEmployeeTableApiResponse,
  DeleteEmployeeProps,
  EditEmployeeProfileApiResponse,
  EditEmployeeTableProps,
  GetEmployeeProfileApiResponse,
  GetEmployeeProfileProps,
  GetEmployeeTableAPIResponse,
  GetEmployeeTableDataProps,
  InputDataType,
} from "@/types/crud.types";
import { createAsyncThunkWithTokenRefresh } from "../apiUtils";
import axiosInstance from "@/lib/axiosInstance";

const initialState: CrudInitialState = {
  // get employee table data
  data: null,
  isLoading: false,
  isError: false,
  error: "",
  isSuccess: false,

  // get employee profile
  employeeProfileData: null,
  employeeProfileIsLoading: false,
  employeeProfileIsError: false,
  employeeProfileError: "",
  employeeProfileIsSuccess: false,

  // add employee table data
  employeeAddedData: null,
  employeeAddDataLoading: false,
  employeeAddedDataIsError: false,
  employeeAddedDataError: "",
  employeeAddedDataIsSuccess: false,

  // edit employee table data
  employeeEditedData: null,
  employeeEditDataLoading: false,
  employeeEditDataIsError: false,
  employeeEditDataError: "",
  employeeEditDataIsSuccess: false,

  // delete employee table data
  employeeDeletedData: null,
  employeeDeleteDataLoading: false,
  employeeDeleteDataIsError: false,
  employeeDeleteDataError: "",
  employeeDeleteDataIsSuccess: false,
};

export const getEmployeeTableData = createAsyncThunkWithTokenRefresh(
  "employeeTable/getEmployeeTableData",
  async (payload: GetEmployeeTableDataProps) => {
    const { search, gender, status, sort, page } = payload;
    return axiosInstance.get<GetEmployeeTableAPIResponse>(
      `/employeesTable?search=${search}&gender=${gender}&status=${status}&sort=${sort}&page=${page}`,
      { headers: { testId: "testID", testNumber: 123 } } // add headers if any
    );
  }
);

// Typically, GET requests are not designed to have a request body according to the HTTP specification.

// However, some APIs may allow it. If you need to send a request body with a GET, below is example
// const handleRequest = async () => {
//   try {
//     const response = await axios({
//       method: 'GET',
//       url: 'https://api.example.com/endpoint', // Replace with your API endpoint
//       params: {
//         // Query parameters
//         param1: 'value1',
//         param2: 'value2'
//       },
//       headers: {
//         'Authorization': 'Bearer your_token_here', // Example authentication header
//         'Content-Type': 'application/json' // Set Content-Type if needed
//       },
//       data: {
//         // Request body (not standard for GET requests)
//         key1: 'value1',
//         key2: 'value2'
//       }
//     });
//     setData(response.data); // Set response data to state
//   } catch (err) {
//     setError(err); // Set error to state
//   }
// };

export const getEmployeeProfileData = createAsyncThunkWithTokenRefresh(
  "employeeTable/getEmployeeProfileData",
  async (payload: GetEmployeeProfileProps) => {
    return axiosInstance.get<GetEmployeeProfileApiResponse>(
      `/employeesTable/${payload.id}`,
      { headers: { testId: "testID", testNumber: 123 } } // add headers if any
    );
  }
);

export const addEmployeeTableData = createAsyncThunkWithTokenRefresh(
  "employeeTable/addEmployeeTableData",
  async (payload: InputDataType) => {
    return axiosInstance.post<AddSuccessApiResponse>(
      `/addEmployee`,
      payload,
      { headers: { testId: "testID", testNumber: 123 } } // add headers if any
    );
  }
);

// post, put, patch request example with both body and params
// const handlePostRequest = async () => {
//   try {
//     const response = await axios.post(
//       'https://api.example.com/endpoint', // Replace with your API endpoint
//       {
//         // Request body
//         key1: 'value1',
//         key2: 'value2'
//       },
//       {
//         params: {
//           // Query parameters
//           param1: 'value1',
//           param2: 'value2'
//         },
//         headers: {
//           'Authorization': 'Bearer your_token_here', // Example authentication header
//           'Content-Type': 'application/json' // Ensure this header is set if sending JSON body
//         }
//       }
//     );
//     setData(response.data); // Set response data to state
//   } catch (err) {
//     setError(err); // Set error to state
//   }
// };

export const editEmployeeTableData = createAsyncThunkWithTokenRefresh(
  "employeeTable/editEmployeeTableData",
  async (payload: EditEmployeeTableProps) => {
    const { tableRowId, data } = payload;
    return axiosInstance.patch<EditEmployeeProfileApiResponse>(
      `/updateEmployeeDetails/${tableRowId}`,
      data,
      { headers: { testId: "testID", testNumber: 123 } } // add headers if any
    );
  }
);

export const deleteEmployeeTableData = createAsyncThunkWithTokenRefresh(
  "employeeTable/deleteEmployeeTableData",
  async (payload: DeleteEmployeeProps) => {
    const { tableRowId } = payload;
    return axiosInstance.delete<DeleteEmployeeTableApiResponse>(
      `/deleteEmployee/${tableRowId}`,
      { headers: { testId: "testID", testNumber: 123 } } // add headers if any
    );
  }
);

// Typically, DELETE requests don’t have a request body according to the HTTP specification. if we want to send, we can send body after headers
// const handleDeleteRequest = async () => {
//   try {
//     const response = await axios({
//       method: 'DELETE',
//       url: 'https://api.example.com/endpoint/123', // Replace with your API endpoint and resource ID
//       params: {
//         // Query parameters
//         param1: 'value1',
//         param2: 'value2'
//       },
//       headers: {
//         'Authorization': 'Bearer your_token_here', // Example authentication header
//         'Content-Type': 'application/json' // Optional, set if your server expects it
//       },
//       data: {
//         // Request body (not standard for DELETE requests but sometimes supported)
//         key1: 'value1',
//         key2: 'value2'
//       }
//     });
//     setData(response.data); // Set response data to state
//   } catch (err) {
//     setError(err); // Set error to state
//   }
// };

export const employeeTableSlice = createSlice({
  name: "employeeTable",
  initialState,
  reducers: {
    resetGetEmployeeProfile(state) {
      state.employeeProfileData = null;
      state.employeeProfileIsLoading = false;
      state.employeeProfileIsError = false;
      state.employeeProfileError = "";
      state.employeeProfileIsSuccess = false;
    },
    resetAddEmployee(state) {
      state.employeeAddDataLoading = false;
      state.employeeAddedDataIsError = false;
      state.employeeAddedDataError = "";
      state.employeeAddedDataIsSuccess = false;
    },
    resetEditEmployee(state) {
      state.employeeEditDataLoading = false;
      state.employeeEditDataIsError = false;
      state.employeeEditDataError = "";
      state.employeeEditDataIsSuccess = false;
    },
    resetDeleteEmployee(state) {
      state.employeeDeleteDataLoading = false;
      state.employeeDeleteDataIsError = false;
      state.employeeDeleteDataError = "";
      state.employeeDeleteDataIsSuccess = false;
    },
  },
  extraReducers(builder) {
    builder
      .addCase(getEmployeeTableData.pending, (state) => {
        state.data = null;
        state.isLoading = true;
        state.isError = false;
        state.error = "";
        state.isSuccess = false;
      })
      .addCase(getEmployeeTableData.fulfilled, (state, action) => {
        state.data = action.payload as GetEmployeeTableAPIResponse;
        state.isLoading = false;
        state.isError = false;
        state.error = "";
        state.isSuccess = true;
      })
      .addCase(getEmployeeTableData.rejected, (state, action) => {
        state.data = null;
        state.isLoading = false;
        state.isError = true;
        state.error = action.payload as string;
        state.isSuccess = false;
      })
      .addCase(getEmployeeProfileData.pending, (state) => {
        state.employeeProfileData = null;
        state.employeeProfileIsLoading = true;
        state.employeeProfileIsError = false;
        state.employeeProfileError = "";
        state.employeeProfileIsSuccess = false;
      })
      .addCase(getEmployeeProfileData.fulfilled, (state, action) => {
        state.employeeProfileData =
          action.payload as GetEmployeeProfileApiResponse;
        state.employeeProfileIsLoading = false;
        state.employeeProfileIsError = false;
        state.employeeProfileError = "";
        state.employeeProfileIsSuccess = true;
      })
      .addCase(getEmployeeProfileData.rejected, (state, action) => {
        state.employeeProfileData = null;
        state.employeeProfileIsLoading = false;
        state.employeeProfileIsError = true;
        state.employeeProfileError = action.payload as string;
        state.employeeProfileIsSuccess = false;
      })
      .addCase(addEmployeeTableData.pending, (state) => {
        state.employeeAddedData = null;
        state.employeeAddDataLoading = true;
        state.employeeAddedDataIsError = false;
        state.employeeAddedDataError = "";
        state.employeeAddedDataIsSuccess = false;
      })
      .addCase(addEmployeeTableData.fulfilled, (state, action) => {
        state.employeeAddedData = action.payload as AddSuccessApiResponse;
        state.employeeAddDataLoading = false;
        state.employeeAddedDataIsError = false;
        state.employeeAddedDataError = "";
        state.employeeAddedDataIsSuccess = true;
      })
      .addCase(addEmployeeTableData.rejected, (state, action) => {
        state.employeeAddedData = null;
        state.employeeAddDataLoading = false;
        state.employeeAddedDataIsError = true;
        state.employeeAddedDataError = action.payload as string;
        state.employeeAddedDataIsSuccess = false;
      })
      .addCase(editEmployeeTableData.pending, (state) => {
        state.employeeEditedData = null;
        state.employeeEditDataLoading = true;
        state.employeeEditDataIsError = false;
        state.employeeEditDataError = "";
        state.employeeEditDataIsSuccess = false;
      })
      .addCase(editEmployeeTableData.fulfilled, (state, action) => {
        state.employeeEditedData =
          action.payload as EditEmployeeProfileApiResponse;
        state.employeeEditDataLoading = false;
        state.employeeEditDataIsError = false;
        state.employeeEditDataError = "";
        state.employeeEditDataIsSuccess = true;
      })
      .addCase(editEmployeeTableData.rejected, (state, action) => {
        state.employeeEditedData = null;
        state.employeeEditDataLoading = false;
        state.employeeEditDataIsError = true;
        state.employeeEditDataError = action.payload as string;
        state.employeeEditDataIsSuccess = false;
      })
      .addCase(deleteEmployeeTableData.pending, (state) => {
        state.employeeDeletedData = null;
        state.employeeDeleteDataLoading = true;
        state.employeeDeleteDataIsError = false;
        state.employeeDeleteDataError = "";
        state.employeeDeleteDataIsSuccess = false;
      })
      .addCase(deleteEmployeeTableData.fulfilled, (state, action) => {
        state.employeeDeletedData =
          action.payload as DeleteEmployeeTableApiResponse;
        state.employeeDeleteDataLoading = false;
        state.employeeDeleteDataIsError = false;
        state.employeeDeleteDataError = "";
        state.employeeDeleteDataIsSuccess = true;
      })
      .addCase(deleteEmployeeTableData.rejected, (state, action) => {
        state.employeeDeletedData = null;
        state.employeeDeleteDataLoading = false;
        state.employeeDeleteDataIsError = true;
        state.employeeDeleteDataError = action.payload as string;
        state.employeeDeleteDataIsSuccess = false;
      });
  },
});

export const {
  resetAddEmployee,
  resetDeleteEmployee,
  resetEditEmployee,
  resetGetEmployeeProfile,
} = employeeTableSlice.actions;

export default employeeTableSlice.reducer;
