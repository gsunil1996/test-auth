import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { baseUrl } from "../baseUrl";
import {
  AuthInitialState,
  CheckTokenValidityData,
  LoginData,
  LoginProps,
  RefreshData,
  RegisterData,
  RegisterUserProps,
} from "@/types/auth.types";
import { createAsyncThunkWithTokenRefresh } from "../apiUtils";
import handleError from "../errorHandler";
import axiosInstance from "@/lib/axiosInstance";

const initialState: AuthInitialState = {
  // register
  registerData: null,
  registerIsLoading: false,
  registerIsError: false,
  registerError: "",
  registerIsSuccess: false,

  // login
  loginData: null,
  loginIsLoading: false,
  loginIsError: false,
  loginError: "",
  loginIsSuccess: false,

  // refresh
  refreshData: null,
  refreshIsLoading: false,
  refreshIsError: false,
  refreshError: "",
  refreshIsSuccess: false,

  // check token validity
  checkTokenValidityData: null,
  checkTokenValidityIsLoading: false,
  checkTokenValidityIsError: false,
  checkTokenValidityError: "",
  checkTokenValidityIsSuccess: false,
};

export const registerAction = createAsyncThunk(
  "auth/registerAction",
  async (payload: RegisterUserProps, thunkAPI) => {
    try {
      const response = await axios.post<RegisterData>(
        `${baseUrl}/register`,
        payload,
        {
          headers: {},
        }
      );

      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(handleError(error));
    }
  }
);

export const loginAction = createAsyncThunk(
  "auth/loginAction",
  async (payload: LoginProps, thunkAPI) => {
    try {
      const response = await axios.post<LoginData>(
        `${baseUrl}/login`,
        payload,
        {
          headers: {},
        }
      );

      localStorage.setItem("token", response.data.token);
      localStorage.setItem("refresh_token", response.data.refreshToken);
      localStorage.setItem("user_details", JSON.stringify(response.data.user));

      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(handleError(error));
    }
  }
);

export const authRefreshAction = createAsyncThunk(
  "auth/authRefreshAction",
  async (_, thunkAPI) => {
    try {
      const refreshToken = localStorage.getItem("refresh_token");

      if (!refreshToken) {
        throw new Error("Refresh token not found. Please log in again.");
      }

      const response = await axios.get<RefreshData>(`${baseUrl}/refresh`, {
        headers: {
          Authorization: `Bearer ${refreshToken}`,
        },
      });

      if (response.data && response.data.token) {
        localStorage.setItem("token", response.data.token);
        return response.data;
      } else {
        return thunkAPI.rejectWithValue(
          "Refresh token not found. Please log in again."
        );
      }
    } catch (error) {
      return thunkAPI.rejectWithValue(handleError(error));
    }
  }
);

export const checkTokenValidtyAction = createAsyncThunkWithTokenRefresh(
  "auth/checkTokenValidtyAction",
  async () => {
    return axiosInstance.get<CheckTokenValidityData>(`/protected`);
  }
);

export const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    logOut: () => {
      localStorage.clear();
    },
    resetRegisterAction(state) {
      state.registerData = null;
      state.registerIsLoading = false;
      state.registerIsError = false;
      state.registerError = "";
      state.registerIsSuccess = false;
    },
    resetLoginAction(state) {
      state.loginData = null;
      state.loginIsLoading = false;
      state.loginIsError = false;
      state.loginError = "";
      state.loginIsSuccess = false;
    },
    resetRefreshction(state) {
      state.refreshData = null;
      state.refreshIsLoading = false;
      state.refreshIsError = false;
      state.refreshError = "";
      state.refreshIsSuccess = false;
    },
    resetCheckTokenValidtyAction(state) {
      state.checkTokenValidityData = null;
      state.checkTokenValidityIsLoading = false;
      state.checkTokenValidityIsError = false;
      state.checkTokenValidityError = "";
      state.checkTokenValidityIsSuccess = false;
    },
  },
  extraReducers(builder) {
    builder

      // regitser
      .addCase(registerAction.pending, (state) => {
        state.registerData = null;
        state.registerIsLoading = true;
        state.registerIsError = false;
        state.registerError = "";
        state.registerIsSuccess = false;
      })
      .addCase(registerAction.fulfilled, (state, action) => {
        state.registerData = action.payload;
        state.registerIsLoading = false;
        state.registerIsError = false;
        state.registerError = "";
        state.registerIsSuccess = true;
      })
      .addCase(registerAction.rejected, (state, action) => {
        state.registerData = null;
        state.registerIsLoading = false;
        state.registerIsError = true;
        state.registerError = action.payload as string;
        state.registerIsSuccess = false;
      })
      // login
      .addCase(loginAction.pending, (state) => {
        state.loginData = null;
        state.loginIsLoading = true;
        state.loginIsError = false;
        state.loginError = "";
        state.loginIsSuccess = false;
      })
      .addCase(loginAction.fulfilled, (state, action) => {
        // console.log('loginAction Inside fulfilled', action)

        state.loginData = action.payload;
        state.loginIsLoading = false;
        state.loginIsError = false;
        state.loginError = "";
        state.loginIsSuccess = true;
      })
      .addCase(loginAction.rejected, (state, action) => {
        // console.log('loginAction Inside error', action)

        state.loginData = null;
        state.loginIsLoading = false;
        state.loginIsError = true;
        state.loginError = action.payload as string;
        state.loginIsSuccess = false;
      })

      // refresh
      .addCase(authRefreshAction.pending, (state) => {
        state.refreshData = null;
        state.refreshIsLoading = true;
        state.refreshIsError = false;
        state.refreshError = "";
        state.refreshIsSuccess = false;
      })
      .addCase(authRefreshAction.fulfilled, (state, action) => {
        // console.log("Inside fulfilled", action)

        state.refreshData = action.payload;
        state.refreshIsLoading = false;
        state.refreshIsError = false;
        state.refreshError = "";
        state.refreshIsSuccess = true;
      })
      .addCase(authRefreshAction.rejected, (state, action) => {
        // console.log("Inside error", action)
        state.refreshData = null;
        state.refreshIsLoading = false;
        state.refreshIsError = true;
        state.refreshError = action.payload as string;
        state.refreshIsSuccess = false;
      })

      // check token validity
      .addCase(checkTokenValidtyAction.pending, (state) => {
        state.checkTokenValidityData = null;
        state.checkTokenValidityIsLoading = true;
        state.checkTokenValidityIsError = false;
        state.checkTokenValidityError = "";
        state.checkTokenValidityIsSuccess = false;
      })
      .addCase(checkTokenValidtyAction.fulfilled, (state, action) => {
        // console.log("Inside fulfilled", action)

        state.checkTokenValidityData = action.payload as CheckTokenValidityData;
        state.checkTokenValidityIsLoading = false;
        state.checkTokenValidityIsError = false;
        state.checkTokenValidityError = "";
        state.checkTokenValidityIsSuccess = true;
      })
      .addCase(checkTokenValidtyAction.rejected, (state, action) => {
        // console.log("Inside error", action)
        state.checkTokenValidityData = null;
        state.checkTokenValidityIsLoading = false;
        state.checkTokenValidityIsError = true;
        state.checkTokenValidityError = action.payload as string;
        state.checkTokenValidityIsSuccess = false;
      });
  },
});

export const {
  logOut,
  resetLoginAction,
  resetRefreshction,
  resetCheckTokenValidtyAction,
  resetRegisterAction,
} = authSlice.actions;

export default authSlice.reducer;
