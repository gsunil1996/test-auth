export const baseUrl: string =
  "https://redux-toolkit-crud-auth-backend.vercel.app";
